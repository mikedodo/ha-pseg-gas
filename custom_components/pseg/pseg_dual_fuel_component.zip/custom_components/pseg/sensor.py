"""Sensors for the PSE&G Energy integration (Electric & Natural Gas)."""

from __future__ import annotations

from datetime import datetime
import logging
from typing import Any, Dict, Optional

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorStateClass,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfEnergy
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.restore_state import RestoreEntity
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import (
    ATTR_DAYS_USED_FOR_RATE,
    ATTR_ELECTRIC_METER,
    ATTR_GAS_METER,
    ATTR_HISTORY_14D,
    ATTR_IS_EXACT_PORTAL_COST,
    ATTR_LATEST_COST,
    ATTR_LATEST_DATE,
    ATTR_METER,
    ATTR_PREVIOUS_COST,
    ATTR_PREVIOUS_DATE,
    ATTR_PREVIOUS_KWH,
    ATTR_PREVIOUS_THERMS,
    ATTR_RATE_7D_AVG,
    ATTR_RATE_APPLIED,
    ATTR_RATE_APPLIED_GAS,
    ATTR_RATE_SOURCE,
    ATTR_TEMPERATURE_AVG,
    ATTR_TEMPERATURE_HIGH,
    ATTR_TEMPERATURE_LOW,
    DOMAIN,
)
from .coordinator import PsegDataUpdateCoordinator

_LOGGER = logging.getLogger(__name__)

UNIT_THERM = getattr(UnitOfEnergy, "THERM", "therm")


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up PSE&G sensor entries for electricity and natural gas."""
    coordinator: PsegDataUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]

    async_add_entities(
        [
            # Electricity entities
            PsegElectricityYesterdaySensor(coordinator, entry),
            PsegElectricityRateSensor(coordinator, entry),
            # Natural Gas entities
            PsegGasYesterdaySensor(coordinator, entry),
            PsegGasRateSensor(coordinator, entry),
        ]
    )


class PsegElectricityYesterdaySensor(
    CoordinatorEntity[PsegDataUpdateCoordinator], SensorEntity, RestoreEntity
):
    """Sensor for yesterday's total electricity consumption."""

    _attr_device_class = SensorDeviceClass.ENERGY
    _attr_state_class = SensorStateClass.TOTAL
    _attr_native_unit_of_measurement = UnitOfEnergy.KILO_WATT_HOUR
    _attr_has_entity_name = True
    _attr_name = "Electricity Consumption Yesterday"

    def __init__(
        self, coordinator: PsegDataUpdateCoordinator, entry: ConfigEntry
    ) -> None:
        """Initialize the sensor."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_electricity_yesterday"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="PSE&G Energy Meter",
            manufacturer="PSE&G",
            model="MySmartEnergy Dual Fuel Portal",
        )

    @property
    def native_value(self) -> Optional[float]:
        """Return yesterday's total kWh consumption."""
        if not self.coordinator.data:
            return None
        return self.coordinator.data.get("yesterday_kwh")

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return attributes for electricity consumption."""
        if not self.coordinator.data:
            return {}
        d = self.coordinator.data
        return {
            ATTR_METER: d.get("meter"),
            ATTR_LATEST_DATE: d.get("latest_date"),
            ATTR_LATEST_COST: d.get("latest_cost"),
            ATTR_PREVIOUS_DATE: d.get("previous_date"),
            ATTR_PREVIOUS_KWH: d.get("previous_kwh"),
            ATTR_PREVIOUS_COST: d.get("previous_cost"),
            ATTR_HISTORY_14D: d.get("history_14d"),
            ATTR_RATE_APPLIED: d.get("effective_rate"),
            ATTR_RATE_SOURCE: d.get("rate_source"),
            ATTR_TEMPERATURE_AVG: d.get("temperature_avg"),
        }


class PsegElectricityRateSensor(
    CoordinatorEntity[PsegDataUpdateCoordinator], SensorEntity
):
    """Sensor for effective electric rate ($/kWh)."""

    _attr_has_entity_name = True
    _attr_name = "Electricity Effective Rate"
    _attr_native_unit_of_measurement = "USD/kWh"

    def __init__(
        self, coordinator: PsegDataUpdateCoordinator, entry: ConfigEntry
    ) -> None:
        """Initialize the electric rate sensor."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_electric_rate"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="PSE&G Energy Meter",
            manufacturer="PSE&G",
            model="MySmartEnergy Dual Fuel Portal",
        )

    @property
    def native_value(self) -> Optional[float]:
        """Return the effective rate per kWh."""
        return self.coordinator.effective_electric_rate

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return attributes for electric rate."""
        return {
            ATTR_RATE_SOURCE: self.coordinator.electric_rate_source,
        }


class PsegGasYesterdaySensor(
    CoordinatorEntity[PsegDataUpdateCoordinator], SensorEntity, RestoreEntity
):
    """Sensor for yesterday's total natural gas consumption."""

    _attr_device_class = SensorDeviceClass.GAS
    _attr_state_class = SensorStateClass.TOTAL
    _attr_native_unit_of_measurement = UNIT_THERM
    _attr_has_entity_name = True
    _attr_name = "Gas Consumption Yesterday"

    def __init__(
        self, coordinator: PsegDataUpdateCoordinator, entry: ConfigEntry
    ) -> None:
        """Initialize the gas sensor."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_gas_yesterday"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="PSE&G Energy Meter",
            manufacturer="PSE&G",
            model="MySmartEnergy Dual Fuel Portal",
        )

    @property
    def native_value(self) -> Optional[float]:
        """Return yesterday's total natural gas consumption in therms."""
        if not self.coordinator.data:
            return None
        return self.coordinator.data.get("yesterday_therms")

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return attributes for natural gas consumption."""
        if not self.coordinator.data:
            return {}
        d = self.coordinator.data
        return {
            ATTR_METER: d.get("gas_meter"),
            ATTR_LATEST_DATE: d.get("latest_gas_date"),
            ATTR_LATEST_COST: d.get("latest_gas_cost"),
            ATTR_PREVIOUS_DATE: d.get("previous_gas_date"),
            ATTR_PREVIOUS_THERMS: d.get("previous_therms"),
            ATTR_PREVIOUS_COST: d.get("previous_gas_cost"),
            ATTR_HISTORY_14D: d.get("gas_history_14d"),
            ATTR_RATE_APPLIED_GAS: d.get("effective_gas_rate"),
            ATTR_RATE_SOURCE: d.get("gas_rate_source"),
            ATTR_TEMPERATURE_AVG: d.get("temperature_avg"),
        }


class PsegGasRateSensor(
    CoordinatorEntity[PsegDataUpdateCoordinator], SensorEntity
):
    """Sensor for effective natural gas rate ($/therm)."""

    _attr_has_entity_name = True
    _attr_name = "Gas Effective Rate"
    _attr_native_unit_of_measurement = "USD/therm"

    def __init__(
        self, coordinator: PsegDataUpdateCoordinator, entry: ConfigEntry
    ) -> None:
        """Initialize the gas rate sensor."""
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_gas_rate"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="PSE&G Energy Meter",
            manufacturer="PSE&G",
            model="MySmartEnergy Dual Fuel Portal",
        )

    @property
    def native_value(self) -> Optional[float]:
        """Return the effective rate per therm."""
        return self.coordinator.effective_gas_rate

    @property
    def extra_state_attributes(self) -> Dict[str, Any]:
        """Return attributes for gas rate."""
        return {
            ATTR_RATE_SOURCE: self.coordinator.gas_rate_source,
        }
