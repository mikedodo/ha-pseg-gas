"""Config flow for PSE&G Energy integration (Electric & Natural Gas)."""

from __future__ import annotations

import logging
from typing import Any

import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.data_entry_flow import FlowResult

from .const import (
    CONF_ELECTRIC_RATE,
    CONF_GAS_RATE,
    CONF_PASSWORD,
    CONF_USERNAME,
    DEFAULT_ELECTRIC_RATE,
    DEFAULT_GAS_RATE,
    DOMAIN,
)
from .pseg_client import PsegAuthError, PsegClient

_LOGGER = logging.getLogger(__name__)

STEP_USER_DATA_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_USERNAME): str,
        vol.Required(CONF_PASSWORD): str,
        vol.Optional(CONF_ELECTRIC_RATE): str,
        vol.Optional(CONF_GAS_RATE): str,
    }
)


class ConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for PSE&G Energy."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Handle the initial setup step."""
        errors: dict[str, str] = {}

        if user_input is not None:
            username = user_input[CONF_USERNAME]
            password = user_input[CONF_PASSWORD]

            # Set unique ID based on username
            await self.async_set_unique_id(username.lower())
            self._abort_if_unique_id_configured()

            client = PsegClient(username, password)
            try:
                await self.hass.async_add_executor_job(client.login)
            except PsegAuthError:
                errors["base"] = "invalid_auth"
            except Exception:
                _LOGGER.exception("Unexpected exception during login verification")
                errors["base"] = "cannot_connect"
            else:
                return self.async_create_entry(
                    title=f"PSE&G ({username})", data=user_input
                )

        return self.async_show_form(
            step_id="user", data_schema=STEP_USER_DATA_SCHEMA, errors=errors
        )

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> config_entries.OptionsFlow:
        """Create options flow handler."""
        return OptionsFlowHandler(config_entry)


class OptionsFlowHandler(config_entries.OptionsFlow):
    """Handle options flow for PSE&G Energy rates."""

    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        """Initialize options flow."""
        self.config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> FlowResult:
        """Manage the rate options."""
        if user_input is not None:
            return self.async_create_entry(title="", data=user_input)

        current_electric_rate = str(
            self.config_entry.options.get(
                CONF_ELECTRIC_RATE,
                self.config_entry.data.get(CONF_ELECTRIC_RATE, DEFAULT_ELECTRIC_RATE),
            )
        )

        current_gas_rate = str(
            self.config_entry.options.get(
                CONF_GAS_RATE,
                self.config_entry.data.get(CONF_GAS_RATE, DEFAULT_GAS_RATE),
            )
        )

        options_schema = vol.Schema(
            {
                vol.Optional(
                    CONF_ELECTRIC_RATE,
                    default=current_electric_rate,
                ): str,
                vol.Optional(
                    CONF_GAS_RATE,
                    default=current_gas_rate,
                ): str,
            }
        )

        return self.async_show_form(step_id="init", data_schema=options_schema)
