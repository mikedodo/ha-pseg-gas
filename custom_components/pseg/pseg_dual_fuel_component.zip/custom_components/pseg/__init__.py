"""The PSE&G Energy integration (Electric & Natural Gas)."""

from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import CONF_PASSWORD, CONF_USERNAME, Platform
from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.exceptions import ConfigEntryNotReady
from homeassistant.helpers import config_validation as cv

from .const import DOMAIN, SERVICE_REFRESH
from .coordinator import PsegDataUpdateCoordinator
from .pseg_client import PsegAuthError, PsegClient

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [Platform.SENSOR, Platform.BUTTON]

CONFIG_SCHEMA = cv.config_entry_only_config_schema(DOMAIN)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up PSE&G Energy from a config entry."""
    hass.data.setdefault(DOMAIN, {})

    username = entry.data[CONF_USERNAME]
    password = entry.data[CONF_PASSWORD]

    client = PsegClient(username, password)

    try:
        await hass.async_add_executor_job(client.login)
    except PsegAuthError as err:
        _LOGGER.error("Failed to authenticate with PSE&G: %s", err)
        return False
    except Exception as err:
        _LOGGER.error("Failed to connect to PSE&G: %s", err)
        raise ConfigEntryNotReady from err

    coordinator = PsegDataUpdateCoordinator(
        hass, client, dict(entry.data), config_entry=entry
    )

    await coordinator.async_config_entry_first_refresh()

    hass.data[DOMAIN][entry.entry_id] = coordinator

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    async def _async_handle_refresh(call: ServiceCall) -> None:
        """Handle manual refresh service call."""
        _LOGGER.info("Manual PSE&G refresh requested via service call")
        await coordinator.async_request_refresh()

    hass.services.async_register(DOMAIN, SERVICE_REFRESH, _async_handle_refresh)

    entry.async_on_unload(entry.add_update_listener(update_listener))

    return True


async def update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Handle options update."""
    await hass.config_entries.async_reload(entry.entry_id)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)

    return unload_ok
