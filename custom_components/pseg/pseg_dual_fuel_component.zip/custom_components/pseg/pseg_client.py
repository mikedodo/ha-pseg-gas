"""Client for interacting with PSE&G MySmartEnergy / MyMeter API (New Jersey).

Supports both Electric (kWh) and Natural Gas (therms) data extraction.
Uses session cookies to communicate directly with PSE&G MySmartEnergy portal.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json
import logging
import math
import re
import time
from typing import Any, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo

import requests

from .const import DEFAULT_ELECTRIC_RATE, DEFAULT_GAS_RATE

_LOGGER = logging.getLogger(__name__)

BASE_URL = "https://mysmartenergy.nj.pseg.com"
PORTAL_TIMEZONE = ZoneInfo("America/New_York")


def portal_time_to_utc(dt_or_ts: Any, fold: int = 0) -> datetime:
    """Convert portal timestamp/datetime to an aware UTC datetime."""
    if isinstance(dt_or_ts, (int, float)):
        # Handle timestamp in milliseconds or seconds
        ts = dt_or_ts / 1000.0 if dt_or_ts > 1e11 else float(dt_or_ts)
        wall_clock = datetime.fromtimestamp(ts, tz=timezone.utc).replace(
            tzinfo=PORTAL_TIMEZONE, fold=fold
        )
        return wall_clock.astimezone(timezone.utc)
    elif isinstance(dt_or_ts, str):
        try:
            dt = datetime.fromisoformat(dt_or_ts)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=PORTAL_TIMEZONE, fold=fold)
            return dt.astimezone(timezone.utc)
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def point_value(pt: Dict[str, Any]) -> Optional[float]:
    """Extract numeric value from a data point dictionary."""
    if not isinstance(pt, dict):
        return None
    for key in ("y", "val", "value", "v", "usage"):
        if key in pt and pt[key] is not None:
            try:
                fval = float(pt[key])
                return fval if math.isfinite(fval) else None
            except (ValueError, TypeError):
                pass
    return None


class PsegAuthError(Exception):
    """Exception raised for authentication errors."""


class PsegClient:
    """API Client for PSE&G MySmartEnergy portal."""

    def __init__(
        self,
        username: str,
        password: str,
        user_configured_electric_rate: Optional[float] = None,
        user_configured_gas_rate: Optional[float] = None,
    ) -> None:
        """Initialize the client."""
        self.username = username
        self.password = password
        self.user_configured_electric_rate = user_configured_electric_rate
        self.user_configured_gas_rate = user_configured_gas_rate

        self.effective_electric_rate = (
            user_configured_electric_rate or DEFAULT_ELECTRIC_RATE
        )
        self.electric_rate_source = (
            "user_configured" if user_configured_electric_rate else "default"
        )

        self.effective_gas_rate = user_configured_gas_rate or DEFAULT_GAS_RATE
        self.gas_rate_source = (
            "user_configured" if user_configured_gas_rate else "default"
        )

        self.session: Optional[requests.Session] = None
        self._auth_token: Optional[str] = None
        self._meters: List[Dict[str, Any]] = []

    def login(self) -> None:
        """Authenticate with PSE&G MySmartEnergy portal."""
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0.0.0 Safari/537.36"
                ),
                "Accept": "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
            }
        )

        login_url = f"{BASE_URL}/User/Login"
        login_payload = {"UserName": self.username, "Password": self.password}

        try:
            resp = self.session.post(login_url, data=login_payload, timeout=30)
            if resp.status_code != 200 or ("success" not in resp.text.lower() and "redirect" not in resp.text.lower()):
                # Also attempt json API endpoint if MVC form returns non-standard response
                api_login = f"{BASE_URL}/api/v1/auth/login"
                api_resp = self.session.post(api_login, json={"username": self.username, "password": self.password}, timeout=30)
                if api_resp.status_code == 200:
                    data = api_resp.json()
                    self._auth_token = data.get("token")
                else:
                    raise PsegAuthError(f"Login failed for user {self.username}")
        except Exception as err:
            if isinstance(err, PsegAuthError):
                raise
            raise PsegAuthError(f"Connection error during login: {err}") from err

    def get_meters(self) -> List[Dict[str, Any]]:
        """Fetch list of meters for the account."""
        if not self.session:
            self.login()

        # Primary endpoint for meters in MyMeter
        endpoints = [
            f"{BASE_URL}/api/v1/meter/getMeters",
            f"{BASE_URL}/Dashboard/GetMeters",
            f"{BASE_URL}/api/v1/account/getAccountInfo",
        ]

        headers = {}
        if self._auth_token:
            headers["Authorization"] = f"Bearer {self._auth_token}"

        for url in endpoints:
            try:
                resp = self.session.get(url, headers=headers, timeout=20)
                if resp.status_code == 200:
                    try:
                        data = resp.json()
                        meters = data.get("meters") or data.get("data") or data
                        if isinstance(meters, list) and len(meters) > 0:
                            self._meters = meters
                            return meters
                    except ValueError:
                        continue
            except Exception as err:
                _LOGGER.debug("Failed querying meter endpoint %s: %s", url, err)

        return self._meters

    def _classify_meters(self, meters: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Classify meters into electric and natural gas meters."""
        electric_meters = []
        gas_meters = []

        for m in meters:
            m_type = str(
                m.get("utilityType")
                or m.get("serviceType")
                or m.get("commodity")
                or m.get("fuelType")
                or m.get("type")
                or m.get("meterType")
                or ""
            ).lower()
            uom = str(m.get("unit") or m.get("uom") or "").lower()
            name = str(m.get("name") or m.get("description") or "").lower()

            if any(k in m_type or k in uom or k in name for k in ("gas", "therm", "ccf")):
                gas_meters.append(m)
            elif any(k in m_type or k in uom or k in name for k in ("elec", "kwh", "power", "energy")):
                electric_meters.append(m)
            else:
                # Default to electric if unspecified
                electric_meters.append(m)

        return electric_meters, gas_meters

    def get_chart_data(
        self,
        meter_id: Optional[str] = None,
        fuel_type: str = "Electric",
        interval: str = "Hourly",
        days: int = 14,
    ) -> Dict[str, Any]:
        """Fetch chart data from MyMeter getChartDataByInterval / GetChartData endpoint."""
        if not self.session:
            self.login()

        now = datetime.now(PORTAL_TIMEZONE)
        start_dt = now - timedelta(days=days)

        headers = {}
        if self._auth_token:
            headers["Authorization"] = f"Bearer {self._auth_token}"

        payload = {
            "meterId": meter_id or "",
            "fuelType": fuel_type,
            "readingType": "Usage",
            "startDate": start_dt.strftime("%m/%d/%Y"),
            "endDate": now.strftime("%m/%d/%Y"),
            "interval": interval,
        }

        # Try API endpoint first, fallback to Dashboard controller
        endpoints = [
            (f"{BASE_URL}/api/v1/chart/getChartDataByInterval", True),
            (f"{BASE_URL}/Dashboard/GetChartData", False),
        ]

        for url, is_json in endpoints:
            try:
                if is_json:
                    resp = self.session.post(url, json=payload, headers=headers, timeout=30)
                else:
                    resp = self.session.post(url, data=payload, headers=headers, timeout=30)

                if resp.status_code == 200:
                    data = resp.json()
                    if "series" in data or "data" in data or "navSeries" in data:
                        return data
            except Exception as err:
                _LOGGER.debug("Error fetching chart data from %s: %s", url, err)

        return {}

    def _parse_usage_series(
        self,
        chart_data: Dict[str, Any],
        is_gas: bool,
        effective_rate: float,
        rate_source: str,
    ) -> Dict[str, Any]:
        """Parse raw chart data into daily history and hourly records for either fuel."""
        series_list = chart_data.get("series", [])
        nav_series = chart_data.get("navSeries", [])

        target_series = {}
        temp_series = {}

        for s in series_list:
            name = str(s.get("name") or "")
            unit = str(s.get("yAxisTitle") or s.get("unit") or "").lower()
            if "Temperature" in name:
                temp_series = s
            elif is_gas and any(k in name.lower() or k in unit for k in ("gas", "therm", "ccf")):
                target_series = s
            elif not is_gas and any(k in name.lower() or k in unit for k in ("meter", "electric", "kwh")):
                target_series = s

        # Fallback to first non-temperature series if specific name wasn't found
        if not target_series:
            for s in series_list:
                if "Temperature" not in str(s.get("name") or ""):
                    target_series = s
                    break

        default_name = "PSE&G Gas Meter" if is_gas else "PSE&G Electric Meter"
        meter_name = target_series.get("name") or default_name
        detailed_pts = target_series.get("data", [])
        temp_pts = temp_series.get("data", [])

        daily_usage_map: Dict[str, float] = {}
        parsed_pts = []
        prev_x = None

        for pt in detailed_pts:
            if isinstance(pt, dict):
                x = pt.get("x", 0)
                start_utc = portal_time_to_utc(x, fold=1 if x == prev_x else 0)
                prev_x = x
                val = point_value(pt)
                if val is None:
                    continue
                units_consumed = round(val, 4)

                hs = pt.get("hs", {})
                start_str = hs.get("start", "")
                try:
                    date_iso = datetime.strptime(start_str, "%m/%d/%Y").strftime("%Y-%m-%d")
                except Exception:
                    date_iso = start_utc.astimezone(PORTAL_TIMEZONE).strftime("%Y-%m-%d")

                daily_usage_map[date_iso] = round(
                    daily_usage_map.get(date_iso, 0.0) + units_consumed, 4
                )
                parsed_pts.append({
                    "start": start_utc,
                    "date": date_iso,
                    "usage": units_consumed,
                    "x": x,
                })

        sorted_dates = sorted(daily_usage_map.keys())

        # Hourly / interval records with calculated monetary cost
        hourly_records = []
        for p in parsed_pts:
            usage_amount = p["usage"]
            cost_amount = round(usage_amount * effective_rate, 4)
            rec = {
                "start": p["start"],
                "date": p["date"],
                "cost": cost_amount,
                "is_exact_cost": False,
            }
            if is_gas:
                rec["therms"] = usage_amount
            else:
                rec["kwh"] = usage_amount
            hourly_records.append(rec)

        # Build 14-day daily history
        history_14d = []
        for d in sorted_dates:
            day_usage = round(daily_usage_map[d], 2)
            day_cost = round(day_usage * effective_rate, 2)
            day_rec = {
                "date": d,
                "cost": day_cost,
                "is_exact_cost": False,
            }
            if is_gas:
                day_rec["therms"] = day_usage
            else:
                day_rec["kwh"] = day_usage
            history_14d.append(day_rec)

        # Identify latest and previous complete readings (typically yesterday)
        empty_rec = {"date": "None", "kwh": 0.0, "therms": 0.0, "cost": 0.0, "is_exact_cost": False}
        latest_record = history_14d[-1] if history_14d else empty_rec
        prev_record = history_14d[-2] if len(history_14d) > 1 else empty_rec

        latest_temp = temp_pts[-1] if temp_pts else {}
        temp_range = latest_temp.get("tr", "")
        temp_value = point_value(latest_temp)

        res = {
            "meter": meter_name,
            "last_updated": datetime.now(timezone.utc).isoformat(),
            "latest_date": latest_record["date"],
            "latest_cost": latest_record["cost"],
            "previous_date": prev_record["date"],
            "previous_cost": prev_record["cost"],
            "history_14d": history_14d,
            "hourly_records": hourly_records,
            "temperature_range": temp_range,
            "temperature_avg": round(temp_value, 1) if temp_value is not None else None,
            "effective_rate": effective_rate,
            "rate_source": rate_source,
        }

        if is_gas:
            res["yesterday_therms"] = prev_record.get("therms", 0.0)
            res["yesterday_gas_cost"] = prev_record.get("cost", 0.0)
            res["latest_therms"] = latest_record.get("therms", 0.0)
            res["previous_therms"] = prev_record.get("therms", 0.0)
        else:
            res["yesterday_kwh"] = prev_record.get("kwh", 0.0)
            res["yesterday_cost"] = prev_record.get("cost", 0.0)
            res["latest_kwh"] = latest_record.get("kwh", 0.0)
            res["previous_kwh"] = prev_record.get("kwh", 0.0)

        return res

    def get_data(self) -> Dict[str, Any]:
        """Fetch electricity and natural gas usage and cost data."""
        if not self.session:
            self.login()

        # Update configured rates if provided
        if self.user_configured_electric_rate is not None and self.user_configured_electric_rate > 0:
            self.effective_electric_rate = self.user_configured_electric_rate
            self.electric_rate_source = "user_configured"
        else:
            self.effective_electric_rate = DEFAULT_ELECTRIC_RATE
            self.electric_rate_source = "default"

        if self.user_configured_gas_rate is not None and self.user_configured_gas_rate > 0:
            self.effective_gas_rate = self.user_configured_gas_rate
            self.gas_rate_source = "user_configured"
        else:
            self.effective_gas_rate = DEFAULT_GAS_RATE
            self.gas_rate_source = "default"

        # Discover meters
        meters = self.get_meters()
        electric_meters, gas_meters = self._classify_meters(meters)

        # 1. Fetch Electric Data
        elec_meter_id = electric_meters[0].get("id") or electric_meters[0].get("meterId") if electric_meters else None
        elec_chart = self.get_chart_data(meter_id=elec_meter_id, fuel_type="Electric", interval="Hourly")
        elec_data = self._parse_usage_series(
            elec_chart,
            is_gas=False,
            effective_rate=self.effective_electric_rate,
            rate_source=self.electric_rate_source,
        )

        # 2. Fetch Gas Data
        gas_meter_id = gas_meters[0].get("id") or gas_meters[0].get("meterId") if gas_meters else None
        gas_chart = self.get_chart_data(meter_id=gas_meter_id, fuel_type="Gas", interval="Daily")
        # If daily chart returns empty or customer has hourly gas, fallback to interval="Hourly"
        if not gas_chart.get("series"):
            gas_chart = self.get_chart_data(meter_id=gas_meter_id, fuel_type="Gas", interval="Hourly")

        gas_data = self._parse_usage_series(
            gas_chart,
            is_gas=True,
            effective_rate=self.effective_gas_rate,
            rate_source=self.gas_rate_source,
        )

        # Unified response payload
        combined_payload: Dict[str, Any] = {
            "electricity": elec_data,
            "gas": gas_data,
            # Top-level electric backward-compatibility
            "meter": elec_data.get("meter"),
            "yesterday_kwh": elec_data.get("yesterday_kwh", 0.0),
            "yesterday_cost": elec_data.get("yesterday_cost", 0.0),
            "latest_date": elec_data.get("latest_date"),
            "latest_kwh": elec_data.get("latest_kwh", 0.0),
            "latest_cost": elec_data.get("latest_cost", 0.0),
            "previous_date": elec_data.get("previous_date"),
            "previous_kwh": elec_data.get("previous_kwh", 0.0),
            "previous_cost": elec_data.get("previous_cost", 0.0),
            "history_14d": elec_data.get("history_14d", []),
            "hourly_readings": elec_data.get("hourly_records", []),
            "effective_rate": self.effective_electric_rate,
            "rate_source": self.electric_rate_source,
            # Top-level natural gas keys
            "gas_meter": gas_data.get("meter"),
            "yesterday_therms": gas_data.get("yesterday_therms", 0.0),
            "yesterday_gas_cost": gas_data.get("yesterday_gas_cost", 0.0),
            "latest_gas_date": gas_data.get("latest_date"),
            "latest_therms": gas_data.get("latest_therms", 0.0),
            "latest_gas_cost": gas_data.get("latest_cost", 0.0),
            "previous_gas_date": gas_data.get("previous_date"),
            "previous_therms": gas_data.get("previous_therms", 0.0),
            "previous_gas_cost": gas_data.get("previous_cost", 0.0),
            "gas_history_14d": gas_data.get("history_14d", []),
            "gas_hourly_readings": gas_data.get("hourly_records", []),
            "effective_gas_rate": self.effective_gas_rate,
            "gas_rate_source": self.gas_rate_source,
            # Shared environment
            "temperature_range": elec_data.get("temperature_range") or gas_data.get("temperature_range"),
            "temperature_avg": elec_data.get("temperature_avg") or gas_data.get("temperature_avg"),
            "last_updated": datetime.now(timezone.utc).isoformat(),
        }

        return combined_payload
