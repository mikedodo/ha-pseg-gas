"""DataUpdateCoordinator for PSE&G Energy (Electric & Natural Gas)."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
import logging
from typing import Any, Dict, Optional

from homeassistant.components.recorder import get_instance
from homeassistant.components.recorder.models import StatisticData, StatisticMetaData
from homeassistant.components.recorder.statistics import (
    async_add_external_statistics,
    get_last_statistics,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfEnergy
from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .const import (
    CONF_ELECTRIC_RATE,
    CONF_GAS_RATE,
    DEFAULT_ELECTRIC_RATE,
    DEFAULT_GAS_RATE,
    DEFAULT_SCAN_INTERVAL_HOURS,
    DOMAIN,
    STATISTIC_ELECTRICITY_CONSUMED,
    STATISTIC_ELECTRICITY_COST,
    STATISTIC_GAS_CONSUMED,
    STATISTIC_GAS_COST,
)
from .pseg_client import PsegAuthError, PsegClient

_LOGGER = logging.getLogger(__name__)

# Determine Unit for Natural Gas (Home Assistant UnitOfEnergy.THERM or fallback 'therm')
UNIT_THERM = getattr(UnitOfEnergy, "THERM", "therm")


class PsegDataUpdateCoordinator(DataUpdateCoordinator[Dict[str, Any]]):
    """Class to manage fetching PSE&G electric and natural gas data from MyMeter."""

    def __init__(
        self,
        hass: HomeAssistant,
        client: PsegClient,
        entry_data: Dict[str, Any],
        config_entry: Optional[ConfigEntry] = None,
    ) -> None:
        """Initialize the coordinator."""
        self.client = client
        self.entry_data = entry_data
        self.config_entry = config_entry
        self.next_update_time: Optional[datetime] = None
        self._last_valid_data: Optional[Dict[str, Any]] = None
        self.auth_required: bool = False
        self.status: str = "connected"
        self.last_successful_update: Optional[str] = None

        # Electric Rate configuration resolution
        user_electric_rate = None
        if config_entry and config_entry.options.get(CONF_ELECTRIC_RATE) is not None:
            user_electric_rate = config_entry.options.get(CONF_ELECTRIC_RATE)
        elif entry_data.get(CONF_ELECTRIC_RATE) is not None:
            user_electric_rate = entry_data.get(CONF_ELECTRIC_RATE)

        try:
            self.user_configured_electric_rate = (
                float(user_electric_rate)
                if user_electric_rate is not None and float(user_electric_rate) > 0
                else None
            )
        except (ValueError, TypeError):
            self.user_configured_electric_rate = None

        # Gas Rate configuration resolution
        user_gas_rate = None
        if config_entry and config_entry.options.get(CONF_GAS_RATE) is not None:
            user_gas_rate = config_entry.options.get(CONF_GAS_RATE)
        elif entry_data.get(CONF_GAS_RATE) is not None:
            user_gas_rate = entry_data.get(CONF_GAS_RATE)

        try:
            self.user_configured_gas_rate = (
                float(user_gas_rate)
                if user_gas_rate is not None and float(user_gas_rate) > 0
                else None
            )
        except (ValueError, TypeError):
            self.user_configured_gas_rate = None

        # Pass configured rates into client
        self.client.user_configured_electric_rate = self.user_configured_electric_rate
        self.client.user_configured_gas_rate = self.user_configured_gas_rate

        self.effective_electric_rate = (
            self.user_configured_electric_rate or DEFAULT_ELECTRIC_RATE
        )
        self.electric_rate_source = (
            "user_configured" if self.user_configured_electric_rate else "default"
        )

        self.effective_gas_rate = (
            self.user_configured_gas_rate or DEFAULT_GAS_RATE
        )
        self.gas_rate_source = (
            "user_configured" if self.user_configured_gas_rate else "default"
        )

        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(hours=DEFAULT_SCAN_INTERVAL_HOURS),
        )

    async def _async_update_data(self) -> Dict[str, Any]:
        """Fetch electricity and natural gas data from PSE&G API."""
        try:
            data = await self.hass.async_add_executor_job(self.client.get_data)
            self._last_valid_data = data
            self.auth_required = False
            self.status = "connected"
            self.last_successful_update = datetime.now(timezone.utc).isoformat()

            # Update effective rates
            self.effective_electric_rate = data.get(
                "effective_rate", self.effective_electric_rate
            )
            self.electric_rate_source = data.get(
                "rate_source", self.electric_rate_source
            )
            self.effective_gas_rate = data.get(
                "effective_gas_rate", self.effective_gas_rate
            )
            self.gas_rate_source = data.get(
                "gas_rate_source", self.gas_rate_source
            )

            # Insert both electricity and gas statistics into recorder
            await self._insert_statistics(data)
            return data

        except PsegAuthError as err:
            self.auth_required = True
            self.status = "auth_failed"
            _LOGGER.error("Authentication failed during PSE&G data update: %s", err)
            raise UpdateFailed(f"Authentication failed: {err}") from err
        except Exception as err:
            _LOGGER.error("Error fetching PSE&G data: %s", err)
            if self._last_valid_data is not None:
                _LOGGER.warning("Returning stale cached data due to fetch error")
                return self._last_valid_data
            raise UpdateFailed(f"Error communicating with PSE&G API: {err}") from err

    async def _insert_statistics(self, data: Dict[str, Any]) -> None:
        """Insert historical hourly statistics for electricity and gas into Home Assistant recorder."""
        currency = getattr(self.hass.config, "currency", "USD") or "USD"

        # ---------------------------------------------------------
        # 1. Electricity Statistics
        # ---------------------------------------------------------
        hourly_readings_elec = data.get("hourly_readings", [])
        if hourly_readings_elec:
            last_stats_elec = await get_instance(self.hass).async_add_executor_job(
                get_last_statistics, self.hass, 1, STATISTIC_ELECTRICITY_CONSUMED, True, {"sum"}
            )
            last_sum_energy = 0.0
            if STATISTIC_ELECTRICITY_CONSUMED in last_stats_elec and last_stats_elec[STATISTIC_ELECTRICITY_CONSUMED]:
                last_sum_energy = last_stats_elec[STATISTIC_ELECTRICITY_CONSUMED][0].get("sum") or 0.0

            last_cost_stats_elec = await get_instance(self.hass).async_add_executor_job(
                get_last_statistics, self.hass, 1, STATISTIC_ELECTRICITY_COST, True, {"sum"}
            )
            last_sum_cost_elec = 0.0
            if STATISTIC_ELECTRICITY_COST in last_cost_stats_elec and last_cost_stats_elec[STATISTIC_ELECTRICITY_COST]:
                last_sum_cost_elec = last_cost_stats_elec[STATISTIC_ELECTRICITY_COST][0].get("sum") or 0.0

            metadata_energy = StatisticMetaData(
                has_mean=False,
                has_sum=True,
                name="PSE&G Electricity Consumed",
                source=DOMAIN,
                statistic_id=STATISTIC_ELECTRICITY_CONSUMED,
                unit_of_measurement=UnitOfEnergy.KILO_WATT_HOUR,
            )

            metadata_cost_elec = StatisticMetaData(
                has_mean=False,
                has_sum=True,
                name="PSE&G Electricity Cost",
                source=DOMAIN,
                statistic_id=STATISTIC_ELECTRICITY_COST,
                unit_of_measurement=currency,
            )

            stats_energy: list[StatisticData] = []
            stats_cost_elec: list[StatisticData] = []

            running_sum_energy = last_sum_energy
            running_sum_cost_elec = last_sum_cost_elec

            for reading in hourly_readings_elec:
                start_dt = reading["start"] if isinstance(reading.get("start"), datetime) else datetime.fromisoformat(str(reading["start"]))
                kwh = reading.get("kwh", 0.0)
                cost = reading.get("cost", 0.0)

                running_sum_energy += kwh
                running_sum_cost_elec += cost

                stats_energy.append(
                    StatisticData(
                        start=start_dt,
                        state=kwh,
                        sum=running_sum_energy,
                    )
                )
                stats_cost_elec.append(
                    StatisticData(
                        start=start_dt,
                        state=cost,
                        sum=running_sum_cost_elec,
                    )
                )

            async_add_external_statistics(self.hass, metadata_energy, stats_energy)
            async_add_external_statistics(self.hass, metadata_cost_elec, stats_cost_elec)
            _LOGGER.debug(
                "Inserted %d hourly statistic points for PSE&G electricity", len(stats_energy)
            )

        # ---------------------------------------------------------
        # 2. Natural Gas Statistics
        # ---------------------------------------------------------
        hourly_readings_gas = data.get("gas_hourly_readings", []) or data.get("gas", {}).get("hourly_records", [])
        if hourly_readings_gas:
            last_stats_gas = await get_instance(self.hass).async_add_executor_job(
                get_last_statistics, self.hass, 1, STATISTIC_GAS_CONSUMED, True, {"sum"}
            )
            last_sum_gas = 0.0
            if STATISTIC_GAS_CONSUMED in last_stats_gas and last_stats_gas[STATISTIC_GAS_CONSUMED]:
                last_sum_gas = last_stats_gas[STATISTIC_GAS_CONSUMED][0].get("sum") or 0.0

            last_cost_stats_gas = await get_instance(self.hass).async_add_executor_job(
                get_last_statistics, self.hass, 1, STATISTIC_GAS_COST, True, {"sum"}
            )
            last_sum_cost_gas = 0.0
            if STATISTIC_GAS_COST in last_cost_stats_gas and last_cost_stats_gas[STATISTIC_GAS_COST]:
                last_sum_cost_gas = last_cost_stats_gas[STATISTIC_GAS_COST][0].get("sum") or 0.0

            metadata_gas = StatisticMetaData(
                has_mean=False,
                has_sum=True,
                name="PSE&G Natural Gas Consumed",
                source=DOMAIN,
                statistic_id=STATISTIC_GAS_CONSUMED,
                unit_of_measurement=UNIT_THERM,
            )

            metadata_cost_gas = StatisticMetaData(
                has_mean=False,
                has_sum=True,
                name="PSE&G Natural Gas Cost",
                source=DOMAIN,
                statistic_id=STATISTIC_GAS_COST,
                unit_of_measurement=currency,
            )

            stats_gas: list[StatisticData] = []
            stats_cost_gas: list[StatisticData] = []

            running_sum_gas = last_sum_gas
            running_sum_cost_gas = last_sum_cost_gas

            for reading in hourly_readings_gas:
                start_dt = reading["start"] if isinstance(reading.get("start"), datetime) else datetime.fromisoformat(str(reading["start"]))
                therms = reading.get("therms") or reading.get("usage") or 0.0
                cost = reading.get("cost", 0.0)

                running_sum_gas += therms
                running_sum_cost_gas += cost

                stats_gas.append(
                    StatisticData(
                        start=start_dt,
                        state=therms,
                        sum=running_sum_gas,
                    )
                )
                stats_cost_gas.append(
                    StatisticData(
                        start=start_dt,
                        state=cost,
                        sum=running_sum_cost_gas,
                    )
                )

            async_add_external_statistics(self.hass, metadata_gas, stats_gas)
            async_add_external_statistics(self.hass, metadata_cost_gas, stats_cost_gas)
            _LOGGER.debug(
                "Inserted %d statistic points for PSE&G natural gas", len(stats_gas)
            )
