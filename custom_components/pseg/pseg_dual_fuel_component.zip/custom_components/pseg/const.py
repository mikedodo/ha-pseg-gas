"""Constants for the PSE&G Energy integration."""

DOMAIN = "pseg"

CONF_USERNAME = "username"
CONF_PASSWORD = "password"
CONF_ELECTRIC_RATE = "electric_rate"
CONF_GAS_RATE = "gas_rate"

DEFAULT_SCAN_INTERVAL_HOURS = 2
DEFAULT_ELECTRIC_RATE = 0.22  # $0.22 / kWh fallback
DEFAULT_GAS_RATE = 1.05       # $1.05 / therm fallback (PSE&G NJ BGSS + Delivery)

# Attributes - Common & Shared
ATTR_METER = "meter_number"
ATTR_ELECTRIC_METER = "electric_meter_number"
ATTR_GAS_METER = "gas_meter_number"
ATTR_LATEST_DATE = "latest_reading_date"
ATTR_LATEST_COST = "latest_reading_cost"
ATTR_IS_EXACT_PORTAL_COST = "is_exact_portal_cost"
ATTR_PREVIOUS_DATE = "previous_reading_date"
ATTR_PREVIOUS_COST = "previous_reading_cost"
ATTR_PREVIOUS_KWH = "previous_reading_kwh"
ATTR_PREVIOUS_THERMS = "previous_reading_therms"
ATTR_HISTORY_14D = "history_14d"
ATTR_RATE_APPLIED = "rate_applied_usd_per_kwh"
ATTR_RATE_APPLIED_GAS = "rate_applied_usd_per_therm"
ATTR_RATE_SOURCE = "rate_source"
ATTR_RATE_7D_AVG = "derived_7d_avg_usd_per_kwh"
ATTR_DAYS_USED_FOR_RATE = "days_used_for_7d_avg"
ATTR_TEMPERATURE_AVG = "temperature_avg_f"
ATTR_TEMPERATURE_HIGH = "temperature_high_f"
ATTR_TEMPERATURE_LOW = "temperature_low_f"

# Statistic IDs for Home Assistant Recorder / Energy Dashboard
STATISTIC_ELECTRICITY_CONSUMED = f"{DOMAIN}:electricity_consumed"
STATISTIC_ELECTRICITY_COST = f"{DOMAIN}:electricity_cost"
STATISTIC_GAS_CONSUMED = f"{DOMAIN}:gas_consumed"
STATISTIC_GAS_COST = f"{DOMAIN}:gas_cost"

SERVICE_REFRESH = "refresh"
