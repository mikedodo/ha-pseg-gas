"""Button entities for PSE&G Energy integration."""

from __future__ import annotations

import logging

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import PsegDataUpdateCoordinator

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up PSE&G button entities."""
    coordinator: PsegDataUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([PsegRefreshButton(coordinator, entry)])


class PsegRefreshButton(ButtonEntity):
    """Button entity to trigger manual data refresh for PSE&G electricity and gas."""

    _attr_has_entity_name = True
    _attr_name = "Refresh Data"

    def __init__(
        self, coordinator: PsegDataUpdateCoordinator, entry: ConfigEntry
    ) -> None:
        """Initialize button entity."""
        self.coordinator = coordinator
        self._entry = entry
        self._attr_unique_id = f"{entry.entry_id}_refresh_button"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="PSE&G Energy Meter",
            manufacturer="PSE&G",
            model="MySmartEnergy Dual Fuel Portal",
        )

    async def async_press(self) -> None:
        """Handle button press to request immediate update."""
        _LOGGER.info("PSE&G manual refresh button pressed")
        await self.coordinator.async_request_refresh()
